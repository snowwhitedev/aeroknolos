define( function() {
	"use strict";

	return ( /^$|\/(?:java|ecma)script/i );
} );
